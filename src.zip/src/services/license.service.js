﻿const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const { getDataDir } = require('../config/runtime-paths');

const LICENSE_FILE = path.join(getDataDir(), 'license.json'); 
const PUBLIC_KEY_FILE = path.join(getDataDir(), 'license-public.pem');

const API_BASE = String(process.env.LICENSE_API_URL || 'http://localhost:4040/api/licenses').replace(/\/$/, '');
const APP_ID = process.env.LICENSE_APP_ID || 'painel_slide';
const POLL_TIMEOUT_MS = Number(process.env.LICENSE_POLL_TIMEOUT_MS || 6000);

const state = {
  active: false,
  status: 'booting',
  reason: 'initializing',
  expiresAt: null,
  requestId: null,
  lastCheckAt: null,
  machineHash: null
};

function deepSort(value) {
  if (Array.isArray(value)) return value.map((item) => deepSort(item));
  if (value && typeof value === 'object') {
    return Object.keys(value)
      .sort()
      .reduce((acc, key) => {
        acc[key] = deepSort(value[key]);
        return acc;
      }, {});
  }
  if (typeof value === 'string') return value.trim();
  return value;
}

function computeMachineHash(machineData) {
  const normalized = deepSort(machineData);
  return crypto.createHash('sha256').update(JSON.stringify(normalized)).digest('hex');
}

function collectMachineData() {
  const interfaces = os.networkInterfaces();
  const macs = [];

  Object.keys(interfaces).forEach((name) => {
    (interfaces[name] || []).forEach((entry) => {
      if (!entry || entry.internal) return;
      if (!entry.mac || entry.mac === '00:00:00:00:00:00') return;
      macs.push(entry.mac.toLowerCase());
    });
  });

  return {
    hostname: os.hostname(),
    platform: process.platform,
    arch: process.arch,
    cpus: (os.cpus() || []).length,
    totalmem: os.totalmem(),
    username: os.userInfo().username,
    node: process.version,
    macs: [...new Set(macs)].sort()
  };
}

function readJsonSafe(file, fallback) {
  try {
    if (!fs.existsSync(file)) return fallback;
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return fallback;
  }
}

function writeJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
}

function readLicenseStore() {
  return readJsonSafe(LICENSE_FILE, {
    token: null,
    requestId: null,
    issuer: null
  });
}

function saveLicenseStore(data) {
  writeJson(LICENSE_FILE, data);
}

function readPublicKey() {
  if (!fs.existsSync(PUBLIC_KEY_FILE)) return null;
  return fs.readFileSync(PUBLIC_KEY_FILE, 'utf8');
}

function savePublicKey(pem) {
  fs.writeFileSync(PUBLIC_KEY_FILE, pem, 'utf8');
}

async function apiFetch(url, options = {}) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), POLL_TIMEOUT_MS);
  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
      headers: {
        'content-type': 'application/json',
        ...(options.headers || {})
      }
    });
    const json = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(json?.error?.message || json?.error || `HTTP ${response.status}`);
    }
    return json;
  } finally {
    clearTimeout(timeout);
  }
}

async function ensurePublicKeyFromApi() {
  let pem = readPublicKey();
  let issuer = readLicenseStore().issuer || null;

  if (pem) return { pem, issuer };

  const payload = await apiFetch(`${API_BASE}/public-key`, { method: 'GET' });
  pem = payload.publicKeyPem;
  issuer = payload.issuer || null;
  if (!pem) throw new Error('Chave publica da licenca nao foi retornada pela API');

  savePublicKey(pem);
  const current = readLicenseStore();
  saveLicenseStore({ ...current, issuer: issuer || current.issuer || null });
  return { pem, issuer };
}

function validateLocalToken(token, publicKeyPem, machineHash, issuer) {
  try {
    const decoded = jwt.verify(token, publicKeyPem, {
      algorithms: ['RS256'],
      audience: APP_ID,
      ...(issuer ? { issuer } : {})
    });

    if (decoded.sub !== machineHash || decoded.machineHash !== machineHash) {
      return { valid: false, reason: 'machine_mismatch', expiresAt: null };
    }

    return {
      valid: true,
      reason: 'ok',
      expiresAt: decoded.exp ? new Date(decoded.exp * 1000).toISOString() : null
    };
  } catch (error) {
    if (error && error.name === 'TokenExpiredError') {
      return {
        valid: false,
        reason: 'expired',
        expiresAt: error.expiredAt ? error.expiredAt.toISOString() : null
      };
    }

    return { valid: false, reason: 'invalid_token', expiresAt: null };
  }
}

async function requestOrPollLicense(machineData, requestId, reason) {
  if (!requestId) {
    const requested = await apiFetch(`${API_BASE}/request`, {
      method: 'POST',
      body: JSON.stringify({ appId: APP_ID, machineData, reason })
    });
    requestId = requested?.request?.id || null;
  }

  if (!requestId) {
    throw new Error('A API nao retornou requestId de licenca');
  }

  const polled = await apiFetch(`${API_BASE}/poll`, {
    method: 'POST',
    body: JSON.stringify({ appId: APP_ID, requestId, machineData })
  });

  return {
    requestId,
    status: polled.status,
    token: polled.token || null,
    expiresAt: polled.expiresAt || null,
    rejectionReason: polled?.request?.rejectionReason || null
  };
}

async function verifyWithServer(token, machineData) {
  try {
    const result = await apiFetch(`${API_BASE}/verify`, {
      method: 'POST',
      body: JSON.stringify({ appId: APP_ID, token, machineData })
    });
    return result;
  } catch {
    return null;
  }
}

function setState(patch) {
  Object.assign(state, patch, {
    lastCheckAt: new Date().toISOString()
  });
}

async function runLicenseCycle() {
  const machineData = collectMachineData();
  const machineHash = computeMachineHash(machineData);
  const store = readLicenseStore();
  const { pem, issuer } = await ensurePublicKeyFromApi();

  state.machineHash = machineHash;

  if (store.token) {
    const localValidation = validateLocalToken(store.token, pem, machineHash, store.issuer || issuer);
    if (localValidation.valid) {
      const remoteValidation = await verifyWithServer(store.token, machineData);
      if (!remoteValidation || remoteValidation.valid) {
        setState({
          active: true,
          status: 'active',
          reason: 'ok',
          expiresAt: localValidation.expiresAt,
          requestId: store.requestId || null
        });
        return state;
      }
    }
  }

  const cycle = await requestOrPollLicense(machineData, store.requestId, store.token ? 'renewal' : 'first_access');

  if (cycle.status === 'approved' && cycle.token) {
    saveLicenseStore({
      token: cycle.token,
      requestId: cycle.requestId,
      issuer: issuer || store.issuer || null
    });

    const fresh = validateLocalToken(cycle.token, pem, machineHash, issuer || store.issuer || null);
    if (!fresh.valid) {
      setState({
        active: false,
        status: 'blocked',
        reason: fresh.reason,
        expiresAt: fresh.expiresAt,
        requestId: cycle.requestId
      });
      return state;
    }

    setState({
      active: true,
      status: 'active',
      reason: 'approved',
      expiresAt: cycle.expiresAt || fresh.expiresAt,
      requestId: cycle.requestId
    });
    return state;
  }

  saveLicenseStore({
    token: store.token || null,
    requestId: cycle.requestId,
    issuer: issuer || store.issuer || null
  });

  if (cycle.status === 'rejected') {
    setState({
      active: false,
      status: 'blocked',
      reason: cycle.rejectionReason || 'rejected',
      expiresAt: null,
      requestId: cycle.requestId
    });
    return state;
  }

  setState({
    active: false,
    status: 'pending',
    reason: 'awaiting_admin_approval',
    expiresAt: null,
    requestId: cycle.requestId
  });
  return state;
}

async function initializeLicense() {
  try {
    await runLicenseCycle();
  } catch (error) {
    setState({
      active: false,
      status: 'pending',
      reason: `license_service_unreachable: ${error.message}`,
      expiresAt: null
    });
  }
  return state;
}

async function dailyLicenseCheck() {
  return runLicenseCycle().catch((error) => {
    setState({
      active: false,
      status: 'pending',
      reason: `daily_check_failed: ${error.message}`,
      expiresAt: null
    });
    return state;
  });
}

function getLicenseState() {
  return { ...state };
}

function licenseGuard(req, res, next) {
  if (req.path === '/license/status') return next();
  if (req.path.startsWith('/uploads/')) return next();

  if (state.active) return next();

  if (req.path.startsWith('/auth') || req.path.startsWith('/media') || req.path.startsWith('/admin')) {
    return res.status(423).json({
      error: 'Licenca inativa',
      license: getLicenseState()
    });
  }

  res.status(423).send(`
    <html><head><meta charset="utf-8"><title>Licenca Pendente</title>
    <style>body{font-family:Segoe UI,sans-serif;background:#111;color:#f3f3f3;display:flex;align-items:center;justify-content:center;height:100vh;margin:0}main{max-width:520px;border:1px solid #333;background:#1a1a1a;padding:24px;border-radius:12px}small{color:#aaa}</style>
    </head><body><main>
      <h2>Licenca pendente ou expirada</h2>
      <p>Este painel esta bloqueado ate que a licenca seja aprovada pelo administrador da API.</p>
      <p><strong>Status:</strong> ${state.status}</p>
      <p><strong>Motivo:</strong> ${state.reason}</p>
      <p><strong>Solicitacao:</strong> ${state.requestId || '-'}</p>
      <small>Endpoint de status: /license/status</small>
    </main></body></html>
  `);
}

module.exports = {
  initializeLicense,
  dailyLicenseCheck,
  getLicenseState,
  licenseGuard
};
